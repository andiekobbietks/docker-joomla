<?php 
$module  = $displayData['module'];

echo $module->content;